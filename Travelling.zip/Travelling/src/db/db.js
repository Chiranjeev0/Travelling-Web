const mongoose = require("mongoose")

const localURI = 'mongodb://localhost:27017/main'
mongoose.connect("mongodb+srv://cluster0.09htffb.mongodb.net/myFirstDatabase",
{
    useNewUrlParser:true,
    useUnifiedTopology:true,
    useCreateIndex:true
}).then(() => {
    console.log(`connection successful`);
}).catch((e)=>{
    console.log(`no connection`);
});
