const mongoose = require("mongoose")
var MongoClient = require('mongodb').MongoClient;

var url = "mongodb://localhost:27017/Travelling-Web?directConnection=true";
mongoose.connect("mongodb+srv://cluster0.09htffb.mongodb.net/myFirstDatabase",
// mongosh "mongodb+srv://cluster0.09htffb.mongodb.net/myFirstDatabase" --apiVersion 1 --username chiranjeev,
{
    useNewUrlParser:true,
    useUnifiedTopology:true,
    useCreateIndex:true
}).then(() => {
    console.log(`connection successful`);
}).catch((e)=>{
    console.log(`no connection`);
});
// require('./db');
